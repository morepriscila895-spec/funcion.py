import tienda

def principal():

    while True:

        print("\n--- TIENDA ---")
        print("1. Comprar producto")
        print("2. Salir")

        opcion = int(input("Seleccione: "))

        if opcion == 1:

            nombre = input("Nombre del producto: ")
            precio = float(input("Precio: "))
            cantidad = int(input("Cantidad: "))

            total = tienda.calcularTotal(precio, cantidad)
            descuento = tienda.aplicarDescuento(total)

            tienda.mostrarProducto(nombre, descuento)

        elif opcion == 2:
            print("Saliendo...")
            break

        else:
            print("Opción no válida")


principal()