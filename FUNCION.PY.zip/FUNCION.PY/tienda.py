# Funciones de una tienda

def calcularTotal(precio, cantidad):
    return precio * cantidad


def aplicarDescuento(total):
    if total >= 100:
        return total * 0.90
    else:
        return total


def mostrarProducto(nombre, total):
    print("Producto:", nombre)
    print("Total a pagar:", total)